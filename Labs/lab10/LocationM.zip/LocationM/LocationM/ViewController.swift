//
//  ViewController.swift
//  LocationM
//
//  Created by jhonny on 7/21/16.
//  Copyright © 2016 Viva. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()
     var currentLocation = CLLocationCoordinate2D()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
        // Init CoreLocation
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
        //self.mapView.showsUserLocation = true
    }
    
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.last
        
        currentLocation = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
        let myLocationPointRect = MKMapRectMake(currentLocation.latitude, currentLocation.longitude, 0, 0)
        
        var anotation = MKPointAnnotation()
        anotation.coordinate = currentLocation
        anotation.title = "The Location"
        anotation.subtitle = "This is the location !!!"
        //myMap.addAnnotation(anotation)
        
        mapView.addAnnotation(anotation)
        //zoomRect = myLocationPointRect
        print("the current location is \(currentLocation.longitude) , \(currentLocation.longitude)")
        //self.locationManager.stopUpdatingLocation()
    }
    

}

