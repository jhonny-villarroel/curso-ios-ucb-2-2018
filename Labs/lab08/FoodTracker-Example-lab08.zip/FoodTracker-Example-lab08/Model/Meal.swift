//
//  Meal.swift
//  FoodTracker
//
//  Created by jbian on 11/14/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import Foundation
import UIKit

class Meal {
    var name:String
    var photo:UIImage?
    var raiting:Int
    init?(name:String, photo:UIImage?, raiting:Int){
        self.name = name
        self.photo = photo
        self.raiting = raiting
        // contructor Validatio
        if(name.isEmpty || raiting < 0){
            // nil = null
            return nil
        }
    }
}
