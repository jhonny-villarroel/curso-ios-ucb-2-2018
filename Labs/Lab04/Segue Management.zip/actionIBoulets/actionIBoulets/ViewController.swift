//
//  ViewController.swift
//  actionIBoulets
//
//  Created by jbian on 11/9/17.
//  Copyright © 2017 jbian. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var mealLabel: UILabel!
    @IBOutlet weak var mealTxt: UITextField!
    //
    override func viewDidLoad() {
        super.viewDidLoad()
        mealLabel.text = "Hello World Jhonny"
        mealTxt.text = "Default Text"
        
        mealTxt.delegate = self
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func clickButton(_ sender: UIButton) {
        print("Click Button")
        mealLabel.text = mealTxt.text
        
    }
    // MARK text fiel override Methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // hide Keyboard
        //textField.resignFirstResponder()
        
        return true;
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        mealLabel.text = textField.text
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        mealLabel.text = Optional (textField.text! + string)
        return true
    }
    // if return true perform segue
    // if return true No perform segue
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        print("The segue identifier is ---> \(identifier)")
        return true
    }
    //
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let profileController = segue.destination as? ProfileViewController
        profileController?.profileName = "A text"
        
    }
    
    
    
    
    
    
    
    
    // Mark as commented
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // review identifier
        let  profile = (segue.destination as? ProfileViewController)
        profile!.name = "test"
    }
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return true
    }*/
}

