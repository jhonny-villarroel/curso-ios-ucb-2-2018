//
//  ViewController.swift
//  Notifications
//
//  Created by jhonny on 7/25/16.
//  Copyright © 2016 Viva. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var notification: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func showNotification(sender: AnyObject) {
        let notification = UILocalNotification()
        // trigger notification on 5 seconds
        notification.fireDate = NSDate(timeIntervalSinceNow: 5)
        notification.alertBody = "My First Notification"
        notification.alertAction = "Got to Application"
        UIApplication.sharedApplication().applicationIconBadgeNumber = 2
        notification.soundName = UILocalNotificationDefaultSoundName
        notification.userInfo = ["CustomField1": "w00t"]
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

