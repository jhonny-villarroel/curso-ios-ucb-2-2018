var express = require('express');
var router = express.Router();
/* Config johnny - five */
var five = require("johnny-five");
var board = new five.Board();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

/* GET users listing. */
router.get('/led/:status', function(req, res, next) {
  var status = req.params.status
  if(status == "on") {
  	var led = new five.Led(13);

	led.on();
  	

  	res.json({"led":"on"})
  
  }else if(status == "off"){
  	
    // Create an Led on pin 13
  	var led = new five.Led(13);
    // Blink every half second
  	led.off()
  	
  	res.json({"led":"off"})
  }

  //res.send('respond with a resource');

});

module.exports = router;
